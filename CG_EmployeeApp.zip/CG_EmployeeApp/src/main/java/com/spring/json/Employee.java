package com.spring.json;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import io.swagger.annotations.ApiModelProperty;

public class Employee {

	@Min(value=1)
	@ApiModelProperty(value="Employee ID")
	private Long employeeId;
	
	@NotBlank
	@NotNull
	@ApiModelProperty(value="employee Name")
	private String name;
	
	@Min(value=10000)
	@Max(value=10000)
	private double sal;
	
	
	
	
	
	public Employee() {
		
		
		
	}
	
	public Employee(String name, double sal) {
		this.name = name;
		this.sal = sal;
	}

	public Employee(Long employeeId, String name, double sal) {
		this.employeeId = employeeId;
		this.name = name;
		this.sal = sal;
	}

	public Long getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(Long employeeId) {
		this.employeeId = employeeId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getSal() {
		return sal;
	}

	public void setSal(double sal) {
		this.sal = sal;
	}
	public String toString() {
		return employeeId + " - " + name + " - " + sal;
	}
	
}
