package com.spring.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.spring.entity.EmployeeEntity;

public interface EmployeeRepo extends JpaRepository<EmployeeEntity, Long>{
	//List<Employee> findByNameAndSal(String name, double sal);
	

	List<EmployeeEntity> findBySalGreaterThan(Double sal);

	List<EmployeeEntity> findByOrderByNameAsc();

	List<EmployeeEntity> findAllEmployeeByNameAndSal(String name, double sal);

	@Query( "select upper(e.name) from EmployeeEntity e")
	List<String> findAllEmployee();

	List<EmployeeEntity> findByNameStartsWith(char a);
	
	
}
