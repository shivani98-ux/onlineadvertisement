package com.spring.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.entity.EmployeeEntity;
import com.spring.json.Employee;
import com.spring.repo.EmployeeRepo;

@Service
public class EmployeeServiceImpl implements EmployeeService {

	@Autowired
	private EmployeeRepo employeeRepo;
	
	@Override
	public Employee createEmployee(Employee employee) {
		EmployeeEntity employeeEntity = 
				employeeRepo.save(new EmployeeEntity(employee.getName(), employee.getSal()));
		return new Employee(employeeEntity.getEmployeeId(), employeeEntity.getName(), employeeEntity.getSal());
	}

	@Override
	public List<Employee> getAllEmployees() {
		List<EmployeeEntity> employeeEntityList = employeeRepo.findAll();
		List<Employee> employees = new ArrayList<Employee>();
		for(EmployeeEntity employeeEntity: employeeEntityList) {
			employees.add(new Employee(employeeEntity.getEmployeeId(), employeeEntity.getName(), employeeEntity.getSal()));
		}
		return employees;
	}

	@Override
	public List<Employee> getEmployeeSalaryGT(Double sal) {
		List<EmployeeEntity> employeeEntityList = employeeRepo.findBySalGreaterThan(sal);
		List<Employee> employees = new ArrayList<Employee>();
		for(EmployeeEntity employeeEntity: employeeEntityList) {
			employees.add(new Employee(employeeEntity.getEmployeeId(),employeeEntity.getName(), employeeEntity.getSal()));
		}
		
		// TODO Auto-generated method stub
		return employees;
	}
	@Override
	public List<Employee> getEmployeeOrderByName() {
		List<EmployeeEntity> employeeEntityList = employeeRepo.findByOrderByNameAsc();
		List<Employee> employees = new ArrayList<Employee>();
		for(EmployeeEntity employeeEntity: employeeEntityList) {
			employees.add(new Employee(employeeEntity.getEmployeeId(),employeeEntity.getName(), employeeEntity.getSal()));
		}
		
		// TODO Auto-generated method stub
		return employees;
	}

	@Override
	public List<Employee> findByNameAndSal(String name, double sal) {
		// TODO Auto-generated method stub
		List<EmployeeEntity> employeeEntityList = employeeRepo.findAllEmployeeByNameAndSal(name, sal);
		List<Employee> employees = new ArrayList<Employee>();
		for(EmployeeEntity employeeEntity : employeeEntityList)
		{
			employees.add(new Employee(employeeEntity.getEmployeeId(), employeeEntity.getName(), employeeEntity.getSal()));
		}
		return null;
	}

	@Override 
	public List<String> findAllUpperCase() {
		// TODO Auto-generated method stub
		List<String> employeeList = employeeRepo.findAllEmployee();
		System.out.println(employeeList);
		return employeeList;
	}

	@Override
	public List<Employee> findByNameStartsWith(char a) {
		List<EmployeeEntity> employeeEntityList = employeeRepo.findByNameStartsWith(a);
		List<Employee> employees = new ArrayList<Employee>();
		for(EmployeeEntity employeeEntity : employeeEntityList) {
			employees.add(new Employee(employeeEntity.getEmployeeId(),employeeEntity.getName(),employeeEntity.getSal()));
		}
		// TODO Auto-generated method stub
		return employees;
	}

	@Override
	public List<Employee> getEmployeeById(long l) {
		// TODO Auto-generated method stub
		return null;
	}
	


}
