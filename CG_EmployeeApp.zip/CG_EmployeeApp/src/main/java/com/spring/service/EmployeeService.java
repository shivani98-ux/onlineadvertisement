package com.spring.service;

import java.util.List;

import com.spring.json.Employee;

public interface EmployeeService {
	public Employee createEmployee(Employee employee);
	public List<Employee> getAllEmployees();
	public List<Employee> getEmployeeSalaryGT(Double sal);
	public List<Employee> getEmployeeOrderByName();
	public List<Employee> findByNameAndSal(String name, double sal);
	public List<String> findAllUpperCase();
	public List<Employee> findByNameStartsWith(char a);
	public List<Employee> getEmployeeById(long l);
}
