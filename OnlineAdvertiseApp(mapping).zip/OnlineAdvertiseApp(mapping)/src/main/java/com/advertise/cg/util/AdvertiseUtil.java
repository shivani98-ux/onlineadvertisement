package com.advertise.cg.util;

import java.util.ArrayList;
import java.util.List;

import com.advertise.cg.entity.AdvertiseEntity;
import com.advertise.cg.entity.UserEntity;
import com.advertise.cg.json.Advertise;
import com.advertise.cg.json.User;

public class AdvertiseUtil {
	public static Advertise convertAdvertiseEntityIntoAdvertise(AdvertiseEntity advertiseEntity) {
		User user = new User(advertiseEntity.getUser().getUser_id(),advertiseEntity.getUser(). getUser_name(),advertiseEntity.getUser().getUser_address(),
				advertiseEntity.getUser().getUser_contactno(),advertiseEntity.getUser().getUser_email());
		Advertise advertise =
				 new Advertise(advertiseEntity.getAd_id(), advertiseEntity.getTitle(), 
							advertiseEntity.getCategory(),advertiseEntity.getDescription(),advertiseEntity.getPrice(),advertiseEntity.getStatus());
		return advertise;
	}
	public static AdvertiseEntity convertAdvertiseIntoAdvertiseEntity(Advertise advertise, UserEntity userEntity) {
		return new AdvertiseEntity(advertise.getAd_id(), advertise.getTitle(), 
				advertise.getCategory(),advertise.getDescription(),advertise.getPrice(),advertise.getStatus());
		
	}
	public static List<Advertise> convertAdvertiseEntityListIntoAdvertise(List<AdvertiseEntity> advertiseEntityList){
		List<Advertise> advertises = new ArrayList<Advertise>();
		for(AdvertiseEntity advertiseEntity : advertiseEntityList)
		{
			advertises.add(convertAdvertiseEntityIntoAdvertise(advertiseEntity));
		}
		return advertises;
	}

}
