package com.advertise.cg.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.advertise.cg.entity.AdvertiseEntity;
import com.advertise.cg.entity.UserEntity;
import com.advertise.cg.exception.AdvertiseNotFoundException;
import com.advertise.cg.json.Advertise;
import com.advertise.cg.json.User;
import com.advertise.cg.repo.AdvertiseRepo;
import com.advertise.cg.repo.UserRepo;




@Service
@Transactional
public class AdvertiseServiceImpl implements AdvertiseService {

	@Autowired
	public AdvertiseRepo advertiseRepo;
	 @Autowired
	    public UserRepo userRepo;
	
   
    
    
 
    
/*	@Override
	public Advertise getAdvertiseById(long ad_id) throws AdvertiseNotFoundException {
		Optional<AdvertiseEntity> opAdvertiseEntity = advertiseRepo.findById(ad_id);
		if(opAdvertiseEntity.isPresent()) {
			AdvertiseEntity advertiseEntity = opAdvertiseEntity.get();
			User user = new User(advertiseEntity.getUser().getUser_id(),advertiseEntity.getUser(). getUser_name(),advertiseEntity.getUser().getUser_address(),
					advertiseEntity.getUser().getUser_contactno(),advertiseEntity.getUser().getUser_email());
		  return new Advertise(advertiseEntity.getAd_id(), advertiseEntity.getTitle(), 
					advertiseEntity.getCategory(),advertiseEntity.getDescription(),advertiseEntity.getPrice(),advertiseEntity.getStatus());
		}
		// TODO Auto-generated method stub
		else
		{
			throw new AdvertiseNotFoundException("ad_id: " + ad_id);
		}
	}*/
	/*@Override
	public Employee getEmployeeById(long empId) throws EmployeeNotFoundException {
		Optional<EmployeeEntity> opEmployeeEntity = employeeRepo.findById(empId);
		if(opEmployeeEntity.isPresent()) {
			EmployeeEntity employeeEntity = opEmployeeEntity.get();
			Department department = new Department(employeeEntity.getDepartment().getDeptId(), employeeEntity.getDepartment().getName());
			return new Employee(employeeEntity.getEmployeeId(), employeeEntity.getName(), employeeEntity.getSal(), department);
		}
		else {
			throw new EmployeeNotFoundException("empId: " + empId);
		}*/
/*	@Override
	public Advertise createAdvertise(Advertise advertise) {
		AdvertiseEntity advertiseEntity = 
				advertiseRepo.save(new AdvertiseEntity(advertise.getAd_id(), advertise.getTitle(), advertise.getCategory(),advertise.getDescription(),advertise.getPrice(),advertise.getStatus()));
		 return new Advertise(advertiseEntity.getAd_id(), advertiseEntity.getTitle(), advertiseEntity.getCategory(),advertiseEntity.getDescription(),advertiseEntity.getPrice(),advertiseEntity.getStatus());
	}

	@Override
	public List<Advertise> getAllAdvertises() {
		List<AdvertiseEntity> advertiseEntityList = advertiseRepo.findAll();
		List<Advertise> advertises = new ArrayList<Advertise>();
		for(AdvertiseEntity advertiseEntity: advertiseEntityList) {
			advertises.add(new Advertise(advertiseEntity.getAd_id(), advertiseEntity.getTitle(), advertiseEntity.getCategory(),advertiseEntity.getDescription(),advertiseEntity.getPrice(),advertiseEntity.getStatus()));
		}
		// TODO Auto-generated method stub
		return advertises;
	}

	@Override
	public Advertise updateById(Advertise advertise, Long ad_id) {
		Optional<AdvertiseEntity> advertiseEntityOp = advertiseRepo.findById(ad_id);
		if(advertiseEntityOp.isPresent())
		{
			AdvertiseEntity advertiseEntity = advertiseEntityOp.get();
			advertiseEntity.setAd_id(advertise.getAd_id());
			advertiseEntity.setTitle(advertise.getTitle());
			advertiseEntity.setCategory(advertise.getCategory());
			advertiseEntity.setDescription(advertise.getDescription());
			advertiseEntity.setPrice(advertise.getPrice());
			advertiseEntity.setStatus(advertise.getStatus());
			advertiseEntity = advertiseRepo.save(advertiseEntity);
			return new Advertise(advertiseEntity.getAd_id(), advertiseEntity.getTitle(), advertiseEntity.getCategory(),advertiseEntity.getDescription(),advertiseEntity.getPrice(),advertiseEntity.getStatus());
			
		}else {
		// TODO Auto-generated method stub
		return null;
	}
	}

	@Override
	public String deleteById(Long ad_id) throws AdvertiseNotFoundException {
		AdvertiseEntity advertiseEntity = advertiseRepo.findById(ad_id).orElseThrow(()-> new AdvertiseNotFoundException
				("Sorry! No Advertise Found with the given ID "+ad_id));

		advertiseRepo.deleteById(ad_id);
		// TODO Auto-generated method stub
		return "Advertise deleted Sucessfully";
	}

	@Override
	
	public String deleteAdvertiseByTitle(String title) throws AdvertiseNotFoundException {
		
		AdvertiseEntity advertiseEntityList = advertiseRepo.findByTitle(title).orElseThrow(()-> new AdvertiseNotFoundException
				("Sorry! No Advertise Found with the given ID "+title));;
		advertiseRepo.deleteByTitle(title);
		
		// TODO Auto-generated method stub
		return "Advertise deleted Sucessfully";
	}*/




	@Override
	public List<Advertise> getAllAdvertises() {
		List<AdvertiseEntity> advertiseEntityList = advertiseRepo.findAll();
		List<Advertise> advertises = new ArrayList<Advertise>();
		for(AdvertiseEntity advertiseEntity: advertiseEntityList) {
			User user = new User(advertiseEntity.getUser().getUser_id(),advertiseEntity.getUser(). getUser_name(),advertiseEntity.getUser().getUser_address(),
					advertiseEntity.getUser().getUser_contactno(),advertiseEntity.getUser().getUser_email());
			advertises.add(new Advertise(advertiseEntity.getAd_id(), advertiseEntity.getTitle(), advertiseEntity.getCategory(),advertiseEntity.getDescription(),advertiseEntity.getPrice(),advertiseEntity.getStatus()));
			
		}
		// TODO Auto-generated method stub
		return advertises;
	}




	@Override
	public List<User> getAllUser() {
		List<UserEntity> userEntityList = userRepo.findAll();
		List<User> user = new ArrayList<User>();
		for(UserEntity userEntity: userEntityList) {
			user.add (new User(userEntity.getUser_id(),userEntity.getUser_name(),userEntity.getUser_address(),
					userEntity.getUser_contactno(),userEntity.getUser_email()));
		}
		// TODO Auto-generated method stub
		return user;
	}
}

	


	

	

	