package com.advertise.cg.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.advertise.cg.exception.AdvertiseNotFoundException;
import com.advertise.cg.json.Advertise;
import com.advertise.cg.json.User;
import com.advertise.cg.service.AdvertiseService;


import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
@RestController
@CrossOrigin("*")
@RequestMapping("/myapp")
@Api(value="Advertise related REST APIs")
public class AdvertiseController {
	
	@Autowired 
	private AdvertiseService advertiseService;
	
	
	
	@GetMapping(value="advertise", produces=MediaType.APPLICATION_JSON_VALUE)
	public List<Advertise> getAllAdvertises(){
		return advertiseService.getAllAdvertises();
	}
	
	@GetMapping(value="/user", produces= MediaType.APPLICATION_JSON_VALUE)
	
		public List<User> getAllUser() {
			return advertiseService.getAllUser();
		}
	
/*	@GetMapping(value="/advertise/{id}", produces=MediaType.APPLICATION_JSON_VALUE)
	public Advertise getAdvertiseById(@PathVariable("id") String ad_id) 
			throws AdvertiseNotFoundException {
		return advertiseService.getAdvertiseById(Long.parseLong(ad_id));
	}
	*/
	}
/*	@ApiOperation(value="Returns all advertises")
	@ApiResponses(value= {
			@ApiResponse(code=201, message="New advertise created"),
			@ApiResponse(code=404, message="No such advertise found")
	})
	
	
	
	@PostMapping(value="/advertise", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public Advertise createNewAdvertise(@RequestBody Advertise advertise) {
	
	return advertiseService.createAdvertise(advertise);
}


@GetMapping(value="/advertise", produces = MediaType.APPLICATION_JSON_VALUE)
public List<Advertise> getAlladvertise() {
	return advertiseService.getAllAdvertises();
	}


@DeleteMapping(value="/advertise/id/{id}",produces = MediaType.APPLICATION_JSON_VALUE)
public String deleteAdvertiseById(@PathVariable("id") Long ad_id) throws AdvertiseNotFoundException
{
	return advertiseService.deleteById(ad_id);
}
@DeleteMapping(value="/advertise/{title}", produces=MediaType.APPLICATION_JSON_VALUE)
	public String deleteAdvertiseByTitle(@PathVariable("title") String title) 
			throws 	AdvertiseNotFoundException {
		return advertiseService.deleteAdvertiseByTitle(title);
	}

@PutMapping(value="/advertise/{id}",consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)

 public Advertise updateAdvertise(@RequestBody Advertise advertise, @PathVariable Long ad_id)
 {
	 return advertiseService.updateById(advertise, ad_id);
 }

*/


