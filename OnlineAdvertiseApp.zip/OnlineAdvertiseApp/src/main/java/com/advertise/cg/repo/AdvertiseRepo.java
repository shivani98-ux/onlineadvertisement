package com.advertise.cg.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.advertise.cg.entity.AdvertiseEntity;

public interface AdvertiseRepo extends JpaRepository<AdvertiseEntity, Long> {



}
