package com.advertise.cg;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnlineAdvertiseAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(OnlineAdvertiseAppApplication.class, args);
	}

}
