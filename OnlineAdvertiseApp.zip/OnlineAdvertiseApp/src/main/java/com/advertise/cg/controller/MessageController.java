package com.advertise.cg.controller;

import java.util.List;

import org.apache.logging.log4j.message.Message;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

public class MessageController {
	
	
		@PostMapping(value="/message/{id}", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
			public Message createNewmessage(@RequestBody Message message) {
			
			return null;
		}
	
}
