package com.advertise.cg;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlineAdvertiseAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
