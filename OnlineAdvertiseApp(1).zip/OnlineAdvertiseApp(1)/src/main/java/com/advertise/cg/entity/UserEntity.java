package com.advertise.cg.entity;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;


@Entity                     // Declare the class as entity or table
@Table(name="user", schema = "public")    // Declare table name  

public class UserEntity
{

	@Id
	@GeneratedValue
	@Column(name="user_id")
	private Long user_id;

	@Column(name="user_name")
	private String user_name;
	
	@Column(name="address")
	private String user_address;
	
	@Column(name="contact_no")
	private double user_contactno;
	
	@Column(name="email")
	private String user_email;
	/*
	 * creating constructors
	 */
	@OneToMany(cascade={CascadeType.ALL},
			fetch = FetchType.EAGER, mappedBy = "user")
	private Set<AdvertiseEntity> advertises;
	
	
	public UserEntity( Long user_id,String user_name, String user_address, double user_contactno, String user_email,Set<AdvertiseEntity> advertises) 
	{
		
		super();
		this.user_id = user_id;
		this.user_name = user_name;
		this.user_address = user_address;
		this.user_contactno = user_contactno;
		this.user_email = user_email;
		this.advertises = advertises;
		
	}

	public UserEntity( String user_name, String user_address, double user_contactno, String user_email,Set<AdvertiseEntity> advertises) 
	{
		
		super();
		this.user_name = user_name;
		this.user_address = user_address;
		this.user_contactno = user_contactno;
		this.user_email = user_email;
		this.advertises = advertises;
		
	}


	public UserEntity()
	{
		super();
	}
	/*
	 * Creating getter and setter
	 * 
	 */

	public Long getUser_id()
	{
		return user_id;
	}

	public void setUser_id(Long user_id)
	{
		this.user_id = user_id;
	}

	public String getUser_name()
	{
		return user_name;
	}

	public void setUser_name(String user_name) 
	{
		this.user_name = user_name;
	}

	public String getUser_address() 
	{
		return user_address;
	}

	public void setUser_address(String user_address)
	{
		this.user_address = user_address;
	}

	public double getUser_contactno()
	{
		return user_contactno;
	}

	public void setUser_contactno(double user_contactno) 
	{
		this.user_contactno = user_contactno;
	}

	public String getUser_email() 
	{
		return user_email;
	}

	public void setUser_email(String user_email)
	{
		this.user_email = user_email;
	}
	public Set<AdvertiseEntity> getAdvertises() {
		return advertises;
	}
	public void setAdvertises(Set<AdvertiseEntity>advertises)
	{
		this.advertises = advertises;
	}
/*
 * creating toString method
 */
	
	@Override
	public String toString() 
	{
		return "UserEntity [user_id=" + user_id + ", user_name=" + user_name + ", user_address=" + user_address
				+ ", user_contactno=" + user_contactno + ", user_email=" + user_email + "]";
	}

	

}


