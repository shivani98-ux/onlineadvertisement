package com.advertise.cg.controller;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.advertise.cg.json.Advertise;



class AdvertiseControllerTest {
	@Test
	public void testGetAllAdvertise() {
		
		 RestTemplate restTemplate = new RestTemplate();
		HttpHeaders header = new HttpHeaders();
		HttpEntity<String> entity = new HttpEntity<String>(null, header);
		ResponseEntity<String> response = restTemplate.exchange("http://localhost:9090/myapp/advertise", HttpMethod.GET, entity, String.class);
		System.out.println(response+"\n"+response.getBody());
		Assertions.assertNotNull(response.getBody());
}
	@Test
	public void testDeleteAdvertiseByID() {
		
		 RestTemplate restTemplate = new RestTemplate();
		HttpHeaders header = new HttpHeaders();
		HttpEntity<String> entity = new HttpEntity<String>(null, header);
		ResponseEntity<String> response = restTemplate.exchange("http://localhost:9090/myapp/advertise/advertiseid/2", HttpMethod.DELETE, entity, String.class);
		System.out.println(response+"\n"+response.getBody());
		Assertions.assertNotNull(response.getBody());
}
}