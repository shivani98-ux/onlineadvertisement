package com.advertise.cg.service;

import java.util.ArrayList;

import java.util.List;
import java.util.Optional;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.advertise.cg.entity.AdvertiseEntity;
import com.advertise.cg.exception.AdvertiseNotFoundException;
import com.advertise.cg.json.Advertise;
import com.advertise.cg.repo.AdvertiseRepo;





@Service
@Transactional
public class AdvertiseServiceImpl implements AdvertiseService {
	Logger logger = LogManager.getLogger(AdvertiseServiceImpl.class);

	@Autowired
	public AdvertiseRepo advertiseRepo;

	@Override
	public Advertise createAdvertise(Advertise advertise) {
		AdvertiseEntity advertiseEntity = 
				advertiseRepo.save(new AdvertiseEntity(advertise.getAd_id(), advertise.getTitle(), advertise.getCategory(),advertise.getDescription(),advertise.getPrice(),advertise.getStatus()));
		 return new Advertise(advertiseEntity.getAd_id(), advertiseEntity.getTitle(), advertiseEntity.getCategory(),advertiseEntity.getDescription(),advertiseEntity.getPrice(),advertiseEntity.getStatus());
	}

	@Override
	public List<Advertise> getAllAdvertises() {
		List<AdvertiseEntity> advertiseEntityList = advertiseRepo.findAll();
		List<Advertise> advertises = new ArrayList<Advertise>();
		for(AdvertiseEntity advertiseEntity: advertiseEntityList) {
			advertises.add(new Advertise(advertiseEntity.getAd_id(), advertiseEntity.getTitle(), advertiseEntity.getCategory(),advertiseEntity.getDescription(),advertiseEntity.getPrice(),advertiseEntity.getStatus()));
		}
		// TODO Auto-generated method stub
		return advertises;
	}

	@Override
	public String deleteById(Long ad_id) throws AdvertiseNotFoundException {
		Optional<AdvertiseEntity> advertiseEntity = advertiseRepo.findById(ad_id);/*.orElseThrow(()-> new AdvertiseNotFoundException
				("Sorry! No Advertise Found with the given ID "+ad_id));*/
             if(advertiseEntity.isPresent())
             {
		advertiseRepo.deleteById(ad_id);
		// TODO Auto-generated method stub
		return "Advertise deleted Sucessfully";
	}else
	{
		logger.error("Advertisement with id : "+ad_id+" not found");
		throw new AdvertiseNotFoundException("ad_id: " + ad_id);
	}
	}

	@Override
	
	public String deleteAdvertiseByTitle(String title) throws AdvertiseNotFoundException {
		Optional<AdvertiseEntity> opAdvertiseEntity = advertiseRepo.findByTitle(title);
		if(opAdvertiseEntity.isPresent()) {
		
		advertiseRepo.deleteByTitle(title);		
		return "Advertise deleted Sucessfully";
	}else
	{
		logger.error("Advertisement with title : "+title+" not found");
		throw new AdvertiseNotFoundException("title: " + title);
	}
	}

	@Override
	public Advertise getAdvertiseById(long ad_id) throws AdvertiseNotFoundException {
		Optional<AdvertiseEntity> opAdvertiseEntity = advertiseRepo.findById(ad_id);
		if(opAdvertiseEntity.isPresent()) {
			AdvertiseEntity advertiseEntity = opAdvertiseEntity.get();
			logger.info("Returning advertisement with id : "+ad_id);
			return new Advertise(advertiseEntity.getAd_id(), advertiseEntity.getTitle(), advertiseEntity.getCategory(),advertiseEntity.getDescription(),advertiseEntity.getPrice(),advertiseEntity.getStatus());
		}
		else {
			logger.error("Advertisement with id : "+ad_id+" not found");
			throw new AdvertiseNotFoundException("ad_id: " + ad_id);
			//return null;
		}
	}
}

	


	

	

	