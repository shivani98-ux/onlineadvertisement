package com.advertise.cg.controller;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.advertise.cg.exception.AdvertiseNotFoundException;
import com.advertise.cg.json.Advertise;
import com.advertise.cg.service.AdvertiseService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
@RestController
@CrossOrigin("*")
@RequestMapping("/myapp")
@Api(value="Advertise related REST APIs")
public class AdvertiseController {
	
	Logger logger = LogManager.getLogger(AdvertiseController.class);
	@Autowired 
	private AdvertiseService advertiseService;
	
	@ApiOperation(value="Returns deleted advertise")
	@ApiResponses(value= {
			@ApiResponse(code=201, message=" advertise deleted"),
			@ApiResponse(code=404, message="No such advertise found")
	})
	




@GetMapping(value="/advertise", produces = MediaType.APPLICATION_JSON_VALUE)
public List<Advertise> getAlladvertise() {
	return advertiseService.getAllAdvertises();
	}
	@ApiOperation(value="Returns advertisement using advertise id")
	@ApiResponses(value= {
			@ApiResponse(code=201,message="Advertisement of specific id returned"),
			@ApiResponse(code=404,message="No such advertise found"),
	})
	
	@GetMapping(value="/advertise/get/id/{id}", produces=MediaType.APPLICATION_JSON_VALUE)
	public Advertise getAdvertiseById(@PathVariable("id") String ad_id) 
			throws AdvertiseNotFoundException {
		logger.info("Advertise returned successfully");
		return advertiseService.getAdvertiseById(Long.parseLong(ad_id));
	}
	

@DeleteMapping(value="/advertise/advertiseid/{id}",produces = MediaType.APPLICATION_JSON_VALUE)
public String deleteAdvertiseById(@PathVariable("id") Long ad_id) throws AdvertiseNotFoundException
{
	return advertiseService.deleteById(ad_id);
}

@DeleteMapping(value="/advertise/{title}", produces=MediaType.APPLICATION_JSON_VALUE)
	public String deleteAdvertiseByTitle(@PathVariable("title") String title) 
			throws 	AdvertiseNotFoundException {
		return advertiseService.deleteAdvertiseByTitle(title);
	}

/*	@PostMapping(value="/advertise", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
public Advertise createNewAdvertise(@RequestBody Advertise advertise) {

return advertiseService.createAdvertise(advertise);
}*/



}
