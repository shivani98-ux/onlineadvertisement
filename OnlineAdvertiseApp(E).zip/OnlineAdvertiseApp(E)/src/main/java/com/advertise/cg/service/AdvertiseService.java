package com.advertise.cg.service;

import java.util.List;

import com.advertise.cg.exception.AdvertiseNotFoundException;
import com.advertise.cg.json.Advertise;




public interface AdvertiseService {
	
	public Advertise createAdvertise(Advertise advertise);
	public List<Advertise> getAllAdvertises();
	//public Advertise updateById(Advertise advertise, Long ad_id);
	public String deleteById(Long ad_id)throws AdvertiseNotFoundException;
	public String deleteAdvertiseByTitle(String title)throws AdvertiseNotFoundException;
	public Advertise getAdvertiseById(long parseLong)throws AdvertiseNotFoundException;


	
	
	
	
	

	
	

}
