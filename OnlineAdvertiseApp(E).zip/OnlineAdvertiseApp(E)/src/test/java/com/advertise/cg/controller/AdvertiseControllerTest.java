package com.advertise.cg.controller;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.advertise.cg.json.Advertise;



class AdvertiseControllerTest {
	//Test
	@Test
	public void testGetAllAdvertise() {
		
		 RestTemplate restTemplate = new RestTemplate();
		HttpHeaders header = new HttpHeaders();
		HttpEntity<String> entity = new HttpEntity<String>(null, header);
		ResponseEntity<String> response = restTemplate.exchange("http://localhost:9090/myapp/advertise", HttpMethod.GET, entity, String.class);
		System.out.println(response+"\n"+response.getBody());
		Assertions.assertNotNull(response.getBody());
}
/*	@Test
	public void testDeleteAdvertiseByID() {
		
		 RestTemplate restTemplate = new RestTemplate();
		HttpHeaders header = new HttpHeaders();
		HttpEntity<String> entity = new HttpEntity<String>(null, header);
		ResponseEntity<String> response = restTemplate.exchange("http://localhost:9090/myapp/advertise/advertiseid/2", HttpMethod.DELETE, entity, String.class);
		System.out.println(response+"\n"+response.getBody());
		Assertions.assertNotNull(response.getBody());
}*/
	@Test
	public void testDeleteById()
	{
		RestTemplate restTemplate = new RestTemplate();
		restTemplate.delete("http://localhost:9090/myapp/advertise/advertiseid/2");
	}
	@Test
	public void testDeleteBytitle()
	{
		RestTemplate restTemplate = new RestTemplate();
		restTemplate.delete("http://localhost:9090/myapp/advertise/door");
	}
	//TEST CASE TO GET AN ADVERTISE BY ID AS POSITIVE
	@Test
	public void testgetAdvertiseByIdSuccess()
	{
		RestTemplate restTemplate = new RestTemplate();
		Advertise advertise = restTemplate.getForObject("http://localhost:9090/myapp/advertise/get/id/3", Advertise.class);
		assertNotNull(advertise);
	}
	
	//TEST CASE TO READ AN ADVERTISE BY ID AS NEGATIVE
	@Test
	public void testReadAdvertiseByIdNegative()
	{
		RestTemplate restTemplate = new RestTemplate();
		try 
		{
			Advertise advertise = restTemplate.getForObject("http://localhost:9090/myapp/advertise/get/id/-1", Advertise.class);
		}
		catch(Exception e) 
		{
			Advertise advertise = null;
		}
		finally 
		{
			Object advertise = null;
			assertNull(advertise,"Advertise with negative id not found");
		}
	}
	
	//TEST CASE TO READ AN ADVERTISE BY ID AS ZERO
	@Test
	public void testReadAdvertiseByIdZero()
	{
		RestTemplate restTemplate = new RestTemplate();
		try 
		{
			Advertise advertise = restTemplate.getForObject("http://localhost:9090/myapp/advertise/get/id/0", Advertise.class);
		}
		catch(Exception e) 
		{
			Advertise advertise = null;
		}
		finally 
		{
			Object advertise = null;
			assertNull(advertise,"Advertise with id = 0 not found");
		}
	}
	
	//TEST CASE TO READ AN ADVERTISE BY BLANK ID
	@Test
	public void testReadAdvertiseByBlankId()
	{
		RestTemplate restTemplate = new RestTemplate();
		try 
		{
			Advertise advertise = restTemplate.getForObject("http://localhost:9090/myapp/advertise/get/id/", Advertise.class);
		}
		catch(Exception e) 
		{
			Advertise advertise = null;
		}
		finally 
		{
			Object advertise = null;
			assertNull(advertise,"Please enter a valid advertise id");
		}
	}
}
		
	